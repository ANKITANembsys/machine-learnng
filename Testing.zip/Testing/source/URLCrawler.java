package com.ezops.crawlers;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLConnection;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Arrays;
import java.util.List;

import org.apache.commons.io.FileUtils;
import org.ini4j.Wini;
import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;


import com.ezops.utils.EZUtil2;

public class URLCrawler implements Runnable {

	private String crawlThisURL;
	private  List<String> requiredFileFormats;
	private Wini config;


	public URLCrawler(String urlToBeCrawled,  Wini config) {
		this.crawlThisURL = urlToBeCrawled;
		this.config = config;
		this.requiredFileFormats = Arrays.asList(config.get("HTTP").get("requiredFileFormats").split(","));
	}

	public void run() {
		// TODO Auto-generated method stub
		getDataFromURL(crawlThisURL);
	}

	/**
	 * @param urlInfo
	 */
	public void getDataFromURL(String urlInfo) {
		String urlInf = urlInfo;
		String regx = "\\/:*\"?<>|";

		char[] ca = regx.toCharArray();
		for (char c : ca) {
			urlInf = urlInf.replace("" + c, "");
		}

		String dirPath = config.get("HTTP").get("URLCrawlOutput")+ "/URL_" + urlInf;
		createDirectory(dirPath);

		String textDirPath = dirPath + "/BodyText";
		createDirectory(textDirPath);
		// Extract text from BODY part of html of url
		getTextFromBody(textDirPath, urlInfo);

		String docsDirPath = dirPath + "/Documents";
		createDirectory(docsDirPath);
		// Download documents from the website
		getDocsFromUrl(docsDirPath, urlInfo);
	}

	public void createDirectory(String directoryPath) {
		File theDir = new File(directoryPath);
		// if the directory does not exist, create it
		if (!theDir.exists()) {
			boolean result = false;
			try {
				theDir.mkdir();
				result = true;
			} catch (SecurityException se) {
				EZUtil2.getLogger().info(se.getMessage());
			}
			if (result) {
				EZUtil2.getLogger().info("DIR " + directoryPath + " created");
			}
		}
	}

	@SuppressWarnings("deprecation")
	public void getTextFromBody(String pathWhereUrlInfoToBeStored,
			String urlInfo) {
		URL url;
		InputStream is = null;
		try {

			final Path dst = Paths.get(pathWhereUrlInfoToBeStored
					+ "/BodyText_" + "Data.html");
			final BufferedWriter writer;
			writer = Files.newBufferedWriter(dst, StandardCharsets.UTF_8);

			url = new URL(urlInfo);

			URLConnection con = url.openConnection();
			// Get the input stream through URL Connection
			is = con.getInputStream();
			BufferedReader br = new BufferedReader(new InputStreamReader(is));

			String line = null;

			// read each line and write to System.out
			while ((line = br.readLine()) != null) {
				writer.write(line);
				writer.newLine();
			}
			writer.close();
			br.close();

			String html = pathWhereUrlInfoToBeStored + "/BodyText_"
					+ "Data.html";
			Document doc = Jsoup.parse(new File(html), "UTF-8", "");
			String text = doc.body().text();

			FileUtils.writeStringToFile(new File(pathWhereUrlInfoToBeStored
					+ "/BodyText_" + "Data.txt"), text);

			FileUtils.deleteQuietly(new File(pathWhereUrlInfoToBeStored
					+ "/BodyText_" + "Data.html"));

			EZUtil2.getLogger().info(
					"Data copied of URL " + urlInfo + " to a text file !!");

		} catch (MalformedURLException e) {
			// TODO Auto-generated catch block
			System.out.println("MalformedURLException: " + e.getMessage());
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			System.out.println("IOException: " + e.getMessage());
			e.printStackTrace();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			System.out.println("Exception is : " + e.getMessage());
			e.printStackTrace();
		} finally {
			try {
				is.close();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}

	public void getDocsFromUrl(String pathWhereDocsToBeStored, String urlInfo) {
		try {
			Document doc = Jsoup.connect(urlInfo).get();
			Elements links = doc.getElementsByTag("a");
			for (Element link : links) {
				StringBuilder docName = new StringBuilder();
				// Check if the link is required to be downloaded
				Boolean isLinkADocument = checkIfLinkIsADocument(
						link.attr("abs:href"), docName);
				if (isLinkADocument) {
					String docLink = link.attr("abs:href");
					String docPath = pathWhereDocsToBeStored + "/"
							+ docName.toString();
					// Download the document to the destination folder
					saveDocument(docPath, docLink);
				}
			}
		} catch (IOException ex) {
			ex.printStackTrace();
		}
	}

	public Boolean checkIfLinkIsADocument(String link, StringBuilder docName) {
		if (docName.length() != 0)
			docName.delete(0, docName.length() - 1);
		String[] splitContents = link.split("/");
		boolean supportedFormatFound = false;
		if (splitContents.length > 0) {
			String[] innerSplitContents = splitContents[splitContents.length - 1]
					.split("\\.");
			if (innerSplitContents.length > 0) {
				for (String innerSplitContent : innerSplitContents) {
					if (requiredFileFormats.contains(innerSplitContent
							.toLowerCase())
							&& (innerSplitContent
									.equals(innerSplitContents[innerSplitContents.length - 1]))) {
						supportedFormatFound = true;
						docName.append(splitContents[splitContents.length - 1]);
						break;
					}
				}
			}
			return supportedFormatFound;
		}
		return false;
	}

	public void saveDocument(String docPath, String docLink) {
		try {
			FileUtils.copyURLToFile(new URL(docLink), new File(docPath));
			EZUtil2.getLogger().info(
					"Document " + docLink + " has been downloaded..!!");
		} catch (MalformedURLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}
